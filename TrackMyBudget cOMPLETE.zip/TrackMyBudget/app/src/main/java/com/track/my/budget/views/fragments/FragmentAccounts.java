package com.track.my.budget.views.fragments;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.PreferenceController;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.User;
import com.track.my.budget.views.LoginActivity;
import com.track.my.budget.views.MainActivity;

/**
 * Accounts Fragment
 */
public class FragmentAccounts extends Fragment {

    private TextView tvUsername;
    private Button buttLogout;
    private MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return  inflater.inflate(R.layout.fragment_main_accounts, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        activity = (MainActivity) getActivity();

        // Set content.
        this.tvUsername = (TextView) view.findViewById(R.id.tvUsername);
        this.buttLogout = (Button) view.findViewById(R.id.buttLogout);

        this.tvUsername.setText(ApplicationDelegate.sharedInstance().getUser().getUsername());

        this.buttLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext(), R.style.AppCompatAlertDialogStyle);
                builder.setTitle("Delete Account?").setMessage("Are you sure you want to delete this account?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        PreferenceController.getPreferenceController(getContext()).putBoolean(ApplicationDelegate.KEY_LOGGED_IN, false);
                        StorageController.delete(getContext(), User.S_ID);
                        StorageController.delete(getContext(), Category.S_ID);

                        Intent intent = new Intent(getContext(), LoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        activity.finish();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }

}/** end class. */
