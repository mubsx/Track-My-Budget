package com.track.my.budget.views;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.AlertManager;
import com.track.my.budget.controller.PreferenceController;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.Budget;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.Item;
import com.track.my.budget.models.User;
import com.track.my.budget.util.AlertReceiver;
import com.track.my.budget.util.Dater;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Splash Activity shown on application launch
 */
public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        User user = null;
        try {
            user = StorageController.load(this, User.S_ID);
            ApplicationDelegate.sharedInstance().setUser(user);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if (user == null) {
            List<Category> categories = new ArrayList<>();
            categories.add(new Category("Salary", Category.CATEGORY_TYPE_INCOME));
            categories.add(new Category("Loan", Category.CATEGORY_TYPE_INCOME));
            categories.add(new Category("Food", Category.CATEGORY_TYPE_EXPENSE));
            categories.add(new Category("Fuel", Category.CATEGORY_TYPE_EXPENSE));
            categories.add(new Category("Clothing", Category.CATEGORY_TYPE_EXPENSE));
            categories.add(new Category("Medical", Category.CATEGORY_TYPE_EXPENSE));
            ApplicationDelegate.sharedInstance().setCategories(categories);
            try {
                StorageController.save(this, Category.S_ID, categories);
            } catch (IOException e) {
                e.printStackTrace();
            }

            // Initialize budget
            Budget budget = new Budget(Dater.getInstance().getMonthFromCalendar());
            budget.setBudgetAmount(0);
            List<Item> items = new ArrayList<>();
            items.add(new Item("", null, 0, null, false, null, Item.ITEM_TYPE_HEADER));
            budget.setItems(items);
            try {
                StorageController.save(this, Budget.S_ID, budget);
                ApplicationDelegate.sharedInstance().setBudget(budget);

                int year = Dater.getInstance().getYearFromCalendar();
                int month = Dater.getInstance().getMonthFromCalendar();
                int day = 25;

                String date = day + "/" + month + "/" + year;
                Intent intent = new Intent(this, AlertReceiver.class);
                intent.putExtra("title", "Track My Budget");
                intent.putExtra("name", "Monthly Budget End");
                intent.putExtra("category", "All");
                intent.putExtra("amount", "calculate");
                new AlertManager(this, intent).setAlertForDate(date);

            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            // Category
            try {
                List<Category> categories = StorageController.load(this, Category.S_ID);
                ApplicationDelegate.sharedInstance().setCategories(categories);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            // Budget
            try {
                Budget budget = StorageController.load(this, Budget.S_ID);
                ApplicationDelegate.sharedInstance().setBudget(budget);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }

        if (PreferenceController.getPreferenceController(this).getBoolean(ApplicationDelegate.KEY_LOGGED_IN, false)) {
            // launch main
            launchActivity(MainActivity.class);
        } else {
            // launch Login activity
            launchActivity(LoginActivity.class);
        }
    }

    /**
     * Launch a new activity
     *
     * @param clz
     */
    private void launchActivity(final Class<?> clz) {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, clz);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        }, 2000);
    }

}/** end class. */
