package com.track.my.budget.controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.Set;

/**
 * Shared Preferences controller class
 */
public class PreferenceController {

    private Context context;
    private SharedPreferences mPreferences;

    /**
     * Private constructor
     *
     * @param context
     */
    private PreferenceController(Context context) {
        if (context == null) {
            throw new RuntimeException("Error: Context can't be null in " + this.getClass().getName());
        }
        this.context = context;
        this.mPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    /**
     * Save {@link java.lang.String} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param value {@link java.lang.String}
     */
    public void putString(String key, String value) {
        mPreferences.edit().putString(key, value).apply();
    }

    /**
     * Save {@code boolean} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param value {@code boolean}
     */
    public void putBoolean(String key, boolean value) {
        mPreferences.edit().putBoolean(key, value).apply();
    }

    /**
     * Save {@code int} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param value {@code int}
     */
    public void putInt(String key, int value) {
        mPreferences.edit().putInt(key, value).apply();
    }

    /**
     * Save {@code long} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param value {@code long}
     */
    public void putLong(String key, long value) {
        mPreferences.edit().putLong(key, value).apply();
    }

    /**
     * Save {@code float} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param value {@code float}
     */
    public void putFloat(String key, float value) {
        mPreferences.edit().putFloat(key, value).apply();
    }

    /**
     * Save {@link java.util.Set} value in {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param values {@link java.util.Set}
     */
    public void putStringSet(String key, Set<String> values) {
        mPreferences.edit().putStringSet(key, values).apply();
    }

    /**
     * Get {@link java.lang.String} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValue {@link java.lang.String}
     * @return the value as {@link java.lang.String}
     */
    public String getString(String key, String defaultValue) {
        return mPreferences.getString(key, defaultValue);
    }

    /**
     * Get {@code boolean} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValue {@code boolean}
     * @return the value as {@code boolean}
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        return mPreferences.getBoolean(key, defaultValue);
    }


    /**
     * Get {@code int} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValue {@code int}
     * @return the value as {@code int}
     */
    public int getInt(String key, int defaultValue) {
        return mPreferences.getInt(key, defaultValue);
    }

    /**
     * Get {@code long} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValue {@code long}
     * @return the value as {@code long}
     */
    public long getLong(String key, long defaultValue) {
        return mPreferences.getLong(key, defaultValue);
    }

    /**
     * Get {@code float} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValue {@code float}
     * @return the value as {@code float}
     */
    public float getFloat(String key, float defaultValue) {
        return mPreferences.getFloat(key, defaultValue);
    }

    /**
     * Get {@link java.util.Set} out of saved {@link android.content.SharedPreferences}
     *
     * @param key {@link java.lang.String}
     * @param defaultValues {@link java.util.Set}
     * @return the value as {@link java.util.Set}
     */
    public Set<String> getStringSet(String key, Set<String> defaultValues) {
        return mPreferences.getStringSet(key, defaultValues);
    }

    /**
     *
     * @param context
     * @return
     */
    public static PreferenceController getPreferenceController(Context context) {
        return new PreferenceController(context);
    }

}/** end class. */
