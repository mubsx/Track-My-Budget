package com.track.my.budget.controller;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;
import android.util.Log;

import java.util.Calendar;
import java.util.Random;

/**
 * Alert manager class.
 */
public class AlertManager {

    private Context context;
    private Intent intent;

    /**
     *
     * @param context
     * @param intent
     */
    public AlertManager(Context context, Intent intent) {
        this.context = context;
        this.intent = intent;
//        this.intent.setPackage("com.track.my.budget");
//        this.intent.setAction("com.track.my.budget.ALERT_SERVICE");
    }

    /**
     *
     * @param date
     */
    public void setAlertForDate(String date) {
        String[] tokens = date.split("/");
        int day = Integer.parseInt(tokens[0]);
        int month = Integer.parseInt(tokens[1]) - 1;
        Log.e("Month", "Month: [" + month + "]");
        int year = Integer.parseInt(tokens[2]);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.clear();
        calendar.set(year, month, day, 12, 10, 0);
        int reqCode = (int) System.currentTimeMillis();
        PendingIntent pIntent = PendingIntent.getBroadcast(context, reqCode, intent, PendingIntent.FLAG_ONE_SHOT);
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pIntent);
    }

}/** end class. */
