package com.track.my.budget.models;

import java.io.Serializable;
import java.util.Date;

/**
 * Item model
 */
public class Item implements Serializable {

    private static final long serialVersionUID      = 9817L;

    public static final int ITEM_TYPE_HEADER        = 0x00;
    public static final int ITEM_TYPE_ITEM          = 0x01;

    private String name;
    private Category category;
    private int amount;
    private String endDate;
    private boolean alert = false;
    private String alertDate;
    private int itemType;

    /**
     *
     * @param name
     * @param category
     * @param amount
     * @param endDate
     * @param alert
     * @param alertDate
     * @param itemType
     */
    public Item(String name, Category category, int amount, String endDate, boolean alert, String alertDate, int itemType) {
        this.name = name;
        this.category = category;
        this.amount = amount;
        this.endDate = endDate;
        this.alert = alert;
        this.alertDate = alertDate;
        this.itemType = itemType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public boolean isAlert() {
        return alert;
    }

    public void setAlert(boolean alert) {
        this.alert = alert;
    }

    public String getAlertDate() {
        return alertDate;
    }

    public void setAlertDate(String alertDate) {
        this.alertDate = alertDate;
    }

    public int getItemType() {
        return itemType;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

}/** end class. */
