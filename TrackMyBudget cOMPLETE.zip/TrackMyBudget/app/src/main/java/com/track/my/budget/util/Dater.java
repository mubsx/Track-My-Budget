package com.track.my.budget.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Dater {

    private static Dater sInstance = null;

    private final Calendar calendar = Calendar.getInstance();
    private static final String _JAN = "January";
    private static final String _FEB = "February";
    private static final String _MAR = "March";
    private static final String _APR = "April";
    private static final String _MAY = "May";
    private static final String _JUN = "June";
    private static final String _JUL = "July";
    private static final String _AUG = "August";
    private static final String _SEP = "September";
    private static final String _OCT = "October";
    private static final String _NOV = "November";
    private static final String _DEC = "December";

    /**
     *
     * @return format dd-mm-yy
     */
    public String getDate() {
        int day = getDayFromCalendar();
        int month = getMonthFromCalendar();
        int year = getYearFromCalendar();
        String y = year + "";
        String fy = y.substring(2);
        return  day + "-" + month + "-" + fy;
    }

    /**
     *
     * @return Year in format yy
     */
    public String getSubYear() {
        String y = getYearFromCalendar() + "";
        String fy = y.substring(2);
        return fy;
    }

    /**
     *
     * @return std month with first letter capital and rest small.
     */
    public String getMonthStd() {
        int m = getMonthFromCalendar();
        switch (m) {
            case 1:
                return _JAN;
            case 2:
                return _FEB;
            case 3:
                return _MAR;
            case 4:
                return _APR;
            case 5:
                return _MAY;
            case 6:
                return _JUN;
            case 7:
                return _JUL;
            case 8:
                return _AUG;
            case 9:
                return _SEP;
            case 10:
                return _OCT;
            case 11:
                return _NOV;
            case 12:
                return _DEC;
            default:
                return _JAN;
        }
    }

    /**
     *
     * @return std month with first letter capital and rest small.
     */
    public String getMonthStd(int m) {
        switch (m) {
            case 1:
                return _JAN;
            case 2:
                return _FEB;
            case 3:
                return _MAR;
            case 4:
                return _APR;
            case 5:
                return _MAY;
            case 6:
                return _JUN;
            case 7:
                return _JUL;
            case 8:
                return _AUG;
            case 9:
                return _SEP;
            case 10:
                return _OCT;
            case 11:
                return _NOV;
            case 12:
                return _DEC;
            default:
                return _JAN;
        }
    }

    /**
     *
     * @return std month with all alphabets in lowercase
     */
    public String getMonthAllLower() {
        return getMonthStd().toLowerCase();
    }

    /**
     *
     * @return std month with all alphabets capital.
     */
    public String getMonthAllCaps() {
        return getMonthStd().toUpperCase();
    }

    /**
     *
     * @return std date in format Mmmm, dd yyyy
     */
    public String getDateWithMonthFirst() {
        return getMonthStd() + ", " + getDayFromCalendar() + " " + getYearFromCalendar();
    }

    /**
     *
     * @return std date in format Mmmm, dd yy
     */
    public String getDateWithMonthFirstSub() {
        return getMonthStd() + ", " + getDayFromCalendar() + " " + getSubYear();
    }

    /**
     *
     * @return std date in format Mmm, dd yy
     */
    public String getDateWithMonthFirstSubSub() {
        String m = getMonthStd().substring(0, 3);
        return m + ", " + getDayFromCalendar() + " " + getSubYear();
    }

    /**
     *
     * @return std date in format Mmm, dd yyyy
     */
    public String getDateWithMonthFirstSubFull() {
        String m = getMonthStd().substring(0, 3);
        return m + ", " + getDayFromCalendar() + " " + getYearFromCalendar();
    }

    /**
     *
     * @return std date in format dd-mm-yyyy
     */
    public String getFullDate() {
        return getDayFromCalendar() + "-" + getMonthFromCalendar() + "-" + getYearFromCalendar();
    }

    /**
     *
     * @return std date in format dd/mm/yy
     */
    public String getDateWithSlashes() {
        return getDayFromCalendar() + "/" + getMonthFromCalendar() + "/" + getSubYear();
    }

    /**
     *
     * @return std date in format dd/mm/yyyy
     */
    public String getDateWithSlashesFull() {
        return getDayFromCalendar() + "/" + getMonthFromCalendar() + "/" + getYearFromCalendar();
    }

    /**
     *
     * @return std date in format ddth Mmmm, yyyy
     */
    public String getDateStdDayFirst() {
        return getDayFromCalendar() + "th " + getMonthStd() + ", " + getYearFromCalendar();
    }

    /**
     *
     * @return std date in format ddth Mmm, yy
     */
    public String getDateStdDayFirstSub() {
        String y = getSubYear();
        String m = getMonthStd().substring(0, 3);
        return getDayFromCalendar() + "th " + m + ", " + y;
    }

    /**
     *
     * @return
     */
    private int getDayFromCalendar() {
        return calendar.get(Calendar.DAY_OF_MONTH);
    }

    /**
     *
     * @return
     */
    public int getMonthFromCalendar() {
        int m = calendar.get(Calendar.MONTH);
        int j = m+=1;
        return m;
    }

    /**
     *
     * @return
     */
    public int getYearFromCalendar() {
        return calendar.get(Calendar.YEAR);
    }

    /**
     *
     * @return Singleton non synchronized
     */
    public static Dater getInstance() {
        if (sInstance == null) {
            sInstance = new Dater();
        }
        return sInstance;
    }

    /**
     *
     * @return new instance.
     */
    public static Dater newInstance() {
        return new Dater();
    }

    /**
     * reset instance.
     */
    public void resetInstance() {
        if (sInstance != null) {
            sInstance = null;
        }
    }

    /**
     *
     * @param time1 "HH:mm" like "08:00 AM"
     * @param time2 "HH:mm" like "08:00 PM"
     * @return String
     */
    public String getTimeDifference(String time1, String time2) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("HH:mm");
        Date d1 = format.parse(time1);
        Date d2 = format.parse(time2);
        long difference = d2.getTime() - d1.getTime();
        int days = (int) (difference / (1000*60*60*24));
        int hours = (int) ((difference - (1000*60*60*24*days)) / (1000*60*60));
        int min = (int) (difference - (1000*60*60*24*days) - (1000*60*60*hours)) / (1000*60);
        int h = (hours < 0 ? -hours : hours);
        int m = (min < 0 ? -min : min);
        return "" + h + " hours & " + m + " min";
    }

    /**
     *
     * @return
     */
    public String getCurrentTime() {
        int hours = getCurrentHoursTwelveFormat();
        int minutes = calendar.get(Calendar.MINUTE);
        int ampm = calendar.get(Calendar.AM_PM);
        String p = "AM";
        if (ampm == Calendar.AM) {
            p = "AM";
        } else if (ampm == Calendar.PM) {
            p = "PM";
        }
        String h = "";
        if (hours < 10) {
            h = "0" + hours;
        } else {
            h = "" + hours;
        }
        String m = "";
        if (minutes < 10) {
            m = "0" + minutes;
        } else {
            m = "" + minutes;
        }
        return "" + h + ":" + m + " " + p;
    }

    /**
     *
     * @return
     */
    private int getCurrentHoursTwelveFormat() {
        int hours = calendar.get(Calendar.HOUR);
        if (hours > 12 || hours == 0) {
            switch (hours) {
                case 0:
                    return 12;
                case 13:
                    return 1;
                case 14:
                    return 2;
                case 15:
                    return 3;
                case 16:
                    return 4;
                case 17:
                    return 5;
                case 18:
                    return 6;
                case 19:
                    return 7;
                case 20:
                    return 8;
                case 21:
                    return 9;
                case 22:
                    return 10;
                case 23:
                    return 11;
            }
        } else {
            return hours;
        }
        return 0;
    }

    /**
     *
     * @return
     */
    public String getTimeStamp() {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        return timeStamp;
    }

    /**
     *
     * @return
     */
    public String getUnixTimeStamp() {
        long tmp = System.currentTimeMillis() / 1000L;
        return tmp + "";
    }

}/** end class. */
