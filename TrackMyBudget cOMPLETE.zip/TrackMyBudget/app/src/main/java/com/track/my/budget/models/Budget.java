package com.track.my.budget.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Budget model class.
 */
public class Budget implements Serializable  {

    private static final long serialVersionUID      = -1L;

    public static final String S_ID                 = "budget.bk";

    private int month;
    private List<Item> items = new ArrayList<>();
    private int budgetAmount;
    private String currency = "Rs";
    private String note = "Any comment or note will appear here. Tap to edit.";

    public Budget() {

    }

    /**
     *
     * @param month
     */
    public Budget(int month) {
        this.month = month;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public int getBudgetAmount() {
        return budgetAmount;
    }

    public void setBudgetAmount(int budgetAmount) {
        this.budgetAmount = budgetAmount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

}/** end class. */
