package com.track.my.budget.views;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.PreferenceController;

/**
 * Login Activity for user to login
 */
public class LoginActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private AppCompatEditText etUsername;
    private AppCompatEditText etPassword;
    private Button buttonSignup;
    private Button buttonLogin;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Set contents
        this.etUsername = (AppCompatEditText) findViewById(R.id.etUsername);
        this.etPassword = (AppCompatEditText) findViewById(R.id.etPassword);
        this.buttonSignup = (Button) findViewById(R.id.buttSignup);
        this.buttonLogin = (Button) findViewById(R.id.buttLogin);

        if (ApplicationDelegate.sharedInstance().getUser() != null) {
            this.etUsername.setText(ApplicationDelegate.sharedInstance().getUser().getUsername());
            this.etUsername.setEnabled(false);
        }

        this.buttonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        this.buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etPassword.getText().toString().equals(ApplicationDelegate.sharedInstance().getUser().getPassword())) {
                    PreferenceController.getPreferenceController(LoginActivity.this).getBoolean(ApplicationDelegate.KEY_LOGGED_IN, true);
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                } else {
                    makeWarningDialog("Password?", "Invalid or empty password. Please provide the valid password!");
                }
            }
        });

        // Set toolbar
        this.setToolbar();
    }

    private void setToolbar() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar.setTitle(R.string.app_name);
        setSupportActionBar(toolbar);
    }

    private void makeWarningDialog(String title, String text) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        builder.setTitle(title).setMessage(text).setNegativeButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

}/** end class. */
