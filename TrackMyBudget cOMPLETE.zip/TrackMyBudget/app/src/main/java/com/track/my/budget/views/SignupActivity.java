package com.track.my.budget.views;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.PreferenceController;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.User;

import java.io.IOException;

public class SignupActivity extends AppCompatActivity {

    private Toolbar toolbar;

    private AppCompatEditText etUsername;
    private AppCompatEditText etPassword;
    private Button buttonSignup;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Set contents
        this.etUsername = (AppCompatEditText) findViewById(R.id.etUsername);
        this.etPassword = (AppCompatEditText) findViewById(R.id.etPassword);
        this.buttonSignup = (Button) findViewById(R.id.buttSignup);

        this.buttonSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });

        // Set toolbar
        this.setToolbar();
    }

    private void setToolbar() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar.setTitle(R.string.app_name);
        setSupportActionBar(toolbar);
    }

    private void signup() {
        String username = this.etUsername.getText().toString();
        String password = this.etPassword.getText().toString();
        if (username != null && !username.isEmpty()) {
            if (password != null && !password.isEmpty()) {
                User user = new User(username, password);
                try {
                    StorageController.save(this, User.S_ID, user);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                ApplicationDelegate.sharedInstance().setUser(user);
                PreferenceController.getPreferenceController(this).putBoolean(ApplicationDelegate.KEY_LOGGED_IN, true);
                Intent intent = new Intent(SignupActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            } else {
                this.makeWarningDialog("Password?", "Password is required for creating an account.");
            }
        } else {
            this.makeWarningDialog("Username?", "Please provide a valid username.");
        }
    }

    private void makeWarningDialog(String title, String text) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        builder.setTitle(title).setMessage(text).setNegativeButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

}/** end class. */
