package com.track.my.budget.views.util;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.AlertManager;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.Budget;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.Item;
import com.track.my.budget.util.AlertReceiver;
import com.track.my.budget.util.Dater;
import com.track.my.budget.views.MainActivity;

import java.io.IOException;
import java.util.Calendar;

public class BudgetAdapter extends BaseAdapter {

    private MainActivity activity;

    public BudgetAdapter(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return ApplicationDelegate.sharedInstance().getBudget().getItems().size();
    }

    @Override
    public Object getItem(int position) {
        return ApplicationDelegate.sharedInstance().getBudget().getItems();
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public int getItemViewType(int position) {
        return ApplicationDelegate.sharedInstance().getBudget().getItems().get(position).getItemType();
    }

    @Override
    public int getViewTypeCount() {
        return 2;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        switch (getItemViewType(position)) {
            case Item.ITEM_TYPE_HEADER:
                final ViewHolderHeader vhHeader;
                if (convertView == null) {
                    convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.style_list_budget_header, null);
                    vhHeader = new ViewHolderHeader();
                    vhHeader.tvMonth = convertView.findViewById(R.id.tvMonth);
                    vhHeader.etCurrency = convertView.findViewById(R.id.etCurrency);
                    vhHeader.etAmount = convertView.findViewById(R.id.etAmount);
                    vhHeader.etNotes = convertView.findViewById(R.id.etNotes);
                    vhHeader.buttSave = convertView.findViewById(R.id.buttSave);
                    convertView.setTag(vhHeader);
                } else {
                    vhHeader = (ViewHolderHeader) convertView.getTag();
                }

                vhHeader.tvMonth.setText(Dater.getInstance().getMonthStd(ApplicationDelegate.sharedInstance().getBudget().getMonth()) + ", " + Dater.getInstance().getYearFromCalendar());
                vhHeader.etCurrency.setText(ApplicationDelegate.sharedInstance().getBudget().getCurrency());
                vhHeader.etAmount.setText(""  + ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount());
                vhHeader.etNotes.setText(ApplicationDelegate.sharedInstance().getBudget().getNote());
                vhHeader.buttSave.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ApplicationDelegate.sharedInstance().getBudget().setCurrency(vhHeader.etCurrency.getText().toString());
                        ApplicationDelegate.sharedInstance().getBudget().setBudgetAmount(Integer.parseInt(vhHeader.etAmount.getText().toString()));
                        ApplicationDelegate.sharedInstance().getBudget().setNote(vhHeader.etNotes.getText().toString());
                        try {
                            StorageController.save(parent.getContext(), Budget.S_ID, ApplicationDelegate.sharedInstance().getBudget());
                            notifyDataSetChanged();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                });

                break;
            case Item.ITEM_TYPE_ITEM:
                final ViewHolderItem vhItem;
                if (convertView == null) {
                    convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.style_list_budget_items, null);
                    vhItem = new ViewHolderItem();
                    vhItem.etName = convertView.findViewById(R.id.etName);
                    vhItem.tvCategoryType = convertView.findViewById(R.id.tvCategoryType);
                    vhItem.spinCategory = convertView.findViewById(R.id.spinCategory);
                    vhItem.etCurrency = convertView.findViewById(R.id.etCurrency);
                    vhItem.etAmount = convertView.findViewById(R.id.etAmount);
                    vhItem.buttEndDate = convertView.findViewById(R.id.buttEndDate);
                    vhItem.buttAlert = convertView.findViewById(R.id.buttAlert);
                    vhItem.buttUpdate = convertView.findViewById(R.id.buttUpdate);
                    convertView.setTag(vhItem);
                } else {
                    vhItem = (ViewHolderItem) convertView.getTag();
                }
                final Item item = ApplicationDelegate.sharedInstance().getBudget().getItems().get(position);
                vhItem.etName.setText(item.getName());
                if (item.getCategory().getType() == Category.CATEGORY_TYPE_EXPENSE) {
                    vhItem.tvCategoryType.setText("Expense");
                    vhItem.tvCategoryType.setBackgroundResource(R.drawable.bg_rounded_red);
                } else {
                    vhItem.tvCategoryType.setText("Income");
                    vhItem.tvCategoryType.setBackgroundResource(R.drawable.bg_rounded_blue);
                }
                String catNames[] = new String[ApplicationDelegate.sharedInstance().getCategories().size()];
                for (int i = 0; i < ApplicationDelegate.sharedInstance().getCategories().size(); i++) {
                    catNames[i] = ApplicationDelegate.sharedInstance().getCategories().get(i).getName();
                }
                vhItem.spinCategory.setAdapter(new ArrayAdapter<>(parent.getContext(), android.R.layout.simple_spinner_dropdown_item, catNames));
                for (int i = 0; i < catNames.length; i++) {
                    if (item.getCategory().getName().equals(catNames[i])) {
                        vhItem.spinCategory.setSelection(i, true);
                    }
                }
                vhItem.etCurrency.setText(ApplicationDelegate.sharedInstance().getBudget().getCurrency());
                vhItem.etAmount.setText(item.getAmount() + "");
                vhItem.buttEndDate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        new DatePickerDialog(parent.getContext(), new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                vhItem.buttEndDate.setText(String.format("%d/%d/%d", dayOfMonth, month + 1, year));
                            }
                        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                if (item.getAlertDate() != null && !item.getAlertDate().isEmpty()) {
                    vhItem.buttAlert.setText(item.getAlertDate());
                } else {
                    vhItem.buttAlert.setText("Set Alert");
                }
                vhItem.buttAlert.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        new DatePickerDialog(parent.getContext(), new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                String alertDate = String.format("%d/%d/%d", dayOfMonth, month + 1, year);
                                vhItem.buttAlert.setText(String.format("Alert %s", alertDate));
                                ApplicationDelegate.sharedInstance().getBudget().getItems().get(position).setAlertDate(alertDate);
                                ApplicationDelegate.sharedInstance().getBudget().getItems().get(position).setAlert(true);
                                Intent intent = new Intent(activity, AlertReceiver.class);
                                intent.putExtra("title", "Track My Budget");
                                intent.putExtra("name", vhItem.etName.getText());
                                intent.putExtra("category", vhItem.spinCategory.getSelectedItem().toString());
                                intent.putExtra("amount", vhItem.etAmount.getText());
                                new AlertManager(activity, intent).setAlertForDate(alertDate);
                                try {
                                    StorageController.save(parent.getContext(), Budget.S_ID, ApplicationDelegate.sharedInstance().getBudget());
                                    notifyDataSetChanged();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).show();
                    }
                });
                vhItem.buttUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        for (int i = 0; i < ApplicationDelegate.sharedInstance().getBudget().getItems().size(); i++) {
                            Item it = ApplicationDelegate.sharedInstance().getBudget().getItems().get(i);
                            if (it.getName().equals(item.getName())) {
                                it.setName(vhItem.etName.getText().toString());
                                Category category = null;
                                for (Category c : ApplicationDelegate.sharedInstance().getCategories()) {
                                    if (c.getName().equals(vhItem.spinCategory.getSelectedItem())) {
                                        category = c;
                                    }
                                }
                                it.setCategory(category);
                                if (it.getAmount() != Integer.parseInt(vhItem.etAmount.getText().toString())) {
                                    if (category.getType() == Category.CATEGORY_TYPE_EXPENSE) {
                                        ApplicationDelegate.sharedInstance().getBudget().setBudgetAmount(ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount() - Integer.parseInt(vhItem.etAmount.getText().toString()));
                                    } else {
                                        ApplicationDelegate.sharedInstance().getBudget().setBudgetAmount(ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount() + Integer.parseInt(vhItem.etAmount.getText().toString()));
                                    }
                                }
                                it.setAmount(Integer.parseInt(vhItem.etAmount.getText().toString()));
                                it.setEndDate(vhItem.buttEndDate.getText().toString());
                                it.setAlertDate(vhItem.buttAlert.getText().toString());
                                try {
                                    ApplicationDelegate.sharedInstance().getBudget().getItems().set(i, it);
                                    StorageController.save(parent.getContext(), Budget.S_ID, ApplicationDelegate.sharedInstance().getBudget());
                                    notifyDataSetChanged();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }
                });
                break;
                default:
                    break;
        }
        return convertView;
    }

    class ViewHolderHeader {
        TextView tvMonth;
        EditText etCurrency;
        EditText etAmount;
        EditText etNotes;
        Button buttSave;
    }

    class ViewHolderItem {
        EditText etName;
        TextView tvCategoryType;
        Spinner spinCategory;
        EditText etCurrency;
        EditText etAmount;
        Button buttEndDate;
        Button buttAlert;
        Button buttUpdate;
    }

}/** end class. */
