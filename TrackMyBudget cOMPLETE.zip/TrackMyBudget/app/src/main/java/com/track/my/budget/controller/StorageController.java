package com.track.my.budget.controller;

import android.content.Context;

import com.track.my.budget.ApplicationDelegate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Storage Manger class. Controls all storage operations.
 */
public class StorageController {

    /**
     *
     * @param context
     * @param sId
     * @param k
     * @param <K>
     * @throws IOException
     */
    public static <K> void save(Context context, String sId,  K k) throws IOException {
        if (context == null) {
            return;
        }
        ObjectOutputStream os = new ObjectOutputStream(context.openFileOutput(sId, Context.MODE_PRIVATE));
        os.writeObject(k);
        os.close();
    }

    /**
     *
     * @param context
     * @param sId
     * @param <T>
     * @return
     * @throws IOException
     */
    public static <T> T load(Context context, String sId) throws IOException, ClassNotFoundException {
        if (context == null) {
            return null;
        }
        FileInputStream fis = context.openFileInput(sId);
        ObjectInputStream ois = new ObjectInputStream(fis);
        T t = (T) ois.readObject();
        ois.close();
        fis.close();
        return t;
    }

    /**
     *
     * @param context
     * @param sId
     * @return
     */
    public static boolean delete(Context context, String sId) {
        String dir = context.getFilesDir().getAbsolutePath();
        ApplicationDelegate.sharedInstance().setUser(null);
        File f = new File(dir, sId);
        if (f != null) {
            return f.delete();
        }
        return false;
    }

}/** end class. */
