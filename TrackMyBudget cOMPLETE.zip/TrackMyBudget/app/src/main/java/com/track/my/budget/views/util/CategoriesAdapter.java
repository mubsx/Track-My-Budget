package com.track.my.budget.views.util;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.Category;

import java.io.IOException;

/**
 * Adapter class for categories list
 */
public class CategoriesAdapter extends BaseAdapter {


    @Override
    public int getCount() {
        return ApplicationDelegate.sharedInstance().getCategories().size();
    }

    @Override
    public Object getItem(int position) {
        return ApplicationDelegate.sharedInstance().getCategories().get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder vh;
        if (convertView == null) {
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.style_list_categories, null);
            vh = new ViewHolder();
            vh.buttDelete = (ImageView) convertView.findViewById(R.id.buttDelete);
            vh.tvName = (TextView)  convertView.findViewById(R.id.tvName);
            vh.tvType = (TextView) convertView.findViewById(R.id.tvType);
            convertView.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }
        Category c = ApplicationDelegate.sharedInstance().getCategories().get(position);
        if (c.getType() == Category.CATEGORY_TYPE_EXPENSE) {
            vh.tvType.setText("Expense");
            vh.tvType.setBackgroundResource(R.drawable.bg_rounded_red);
        } else {
            vh.tvType.setText("Income");
            vh.tvType.setBackgroundResource(R.drawable.bg_rounded_blue);
        }
        vh.tvName.setText(c.getName());
        vh.buttDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ApplicationDelegate.sharedInstance().getCategories().remove(position);
                try {
                    StorageController.save(parent.getContext(), Category.S_ID, ApplicationDelegate.sharedInstance().getCategories());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                notifyDataSetChanged();
            }
        });
        return convertView;
    }

    class ViewHolder {
        ImageView buttDelete;
        TextView tvName;
        TextView tvType;
    }

}/** end class. */
