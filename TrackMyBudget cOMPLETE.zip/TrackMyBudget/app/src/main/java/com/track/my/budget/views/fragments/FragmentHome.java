package com.track.my.budget.views.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.views.MainActivity;
import com.track.my.budget.views.util.BudgetAdapter;

/**
 * Main Home Fragment
 */
public class FragmentHome extends Fragment {

    private ListView lv;
    private LinearLayout layoutEmpty;
    private MainActivity activity;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.activity = (MainActivity) getActivity();


        this.lv = (ListView) view.findViewById(R.id.lvHome);
        this.layoutEmpty = (LinearLayout) view.findViewById(R.id.layoutEmpty);

        if (ApplicationDelegate.sharedInstance().getBudget().getItems().size() > 0) {
            this.layoutEmpty.setVisibility(View.GONE);
        } else {
            this.layoutEmpty.setVisibility(View.VISIBLE);
        }

        this.lv.setAdapter(new BudgetAdapter(activity));
    }

}/** end class. */
