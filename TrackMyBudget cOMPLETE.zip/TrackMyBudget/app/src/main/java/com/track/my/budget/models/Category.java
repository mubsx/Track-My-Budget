package com.track.my.budget.models;

import java.io.Serializable;

/**
 * Category model
 */
public class Category implements Serializable {

    private static final long serialVersionUID      = -1194L;

    public static final String S_ID                 = "cat.bk";

    public static final int CATEGORY_TYPE_INCOME    = 0x00;
    public static final int CATEGORY_TYPE_EXPENSE   = 0x01;

    private String name;
    private int type;

    /**
     *
     * @param name
     * @param type
     */
    public Category(String name, int type) {
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

}/** end class. */
