package com.track.my.budget.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.Item;

public class AlertReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, "New Alert for Track My Budget!", Toast.LENGTH_LONG);
        Log.e("Alert", "New Alert for Track My Budget!");
        Bundle extras = intent.getExtras();
        String title = extras.getString("title");
        String name = extras.getString("name");
        String category = extras.getString("category");
        String amount = extras.getString("amount");

        if (amount.equals("calculate")) {
            int budget = ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount();
            int income = 0;
            int expense =  0;
            for (int i = 1; i < ApplicationDelegate.sharedInstance().getBudget().getItems().size(); i++) {
                Item item = ApplicationDelegate.sharedInstance().getBudget().getItems().get(i);
                if (item.getCategory().getType() == Category.CATEGORY_TYPE_EXPENSE) {
                    expense += item.getAmount();
                } else {
                    income += item.getAmount();
                }
            }
            int balance = budget - expense;
            amount = "Budget: " + budget + ", Total Expenses: " + expense + ", Total Income: " + income + ", Balance: " + balance;
        }

        String notification = "Name: " + name + "\nCategory: " + category + "\nAmount: " + ApplicationDelegate.sharedInstance().getBudget().getCurrency() + " " + amount;
        ApplicationDelegate.sharedInstance().setNotification(title, notification);
    }

}/** end class. */
