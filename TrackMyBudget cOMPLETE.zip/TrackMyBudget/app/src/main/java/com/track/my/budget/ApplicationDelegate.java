package com.track.my.budget;

import android.app.Application;
import android.content.IntentFilter;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;

import com.track.my.budget.models.Budget;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.User;
import com.track.my.budget.util.AlertReceiver;

import java.util.ArrayList;
import java.util.List;


/**
 * Application delegate class as a Singleton.
 */
public class ApplicationDelegate extends Application {

    private static final String LOG_TAG = ApplicationDelegate.class.getName().toUpperCase();

    private static ApplicationDelegate sInstance = null;

    public static final String KEY_LOGGED_IN        = "logged_in";

    private AlertReceiver receiver;

    private User user;
    private List<Category> categories = new ArrayList<>();
    private Budget budget;

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;

//        this.receiver = new AlertReceiver();
//        IntentFilter iF = new IntentFilter("com.track.my.budget.ALERT_SERVICE");
//        this.registerReceiver(receiver, iF);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Category> getCategories() {
        return categories;
    }

    public void setCategories(List<Category> categories) {
        this.categories = categories;
    }

    public Budget getBudget() {
        return budget;
    }

    public void setBudget(Budget budget) {
        this.budget = budget;
    }

    /**
     *
     * @param title
     * @param text
     */
    public void setNotification(String title, String text) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "COM.TRACK.MY.BUDGET");
        builder.setSmallIcon(R.mipmap.ic_launcher_round).setContentTitle(title).setContentText("New Alert received");
        builder.setStyle(new NotificationCompat.BigTextStyle().bigText(text));
        builder.setPriority(NotificationCompat.PRIORITY_HIGH);
        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.notify(997, builder.build());
    }

    /**
     *
     * @return {@link com.track.my.budget.ApplicationDelegate} as a singleton
     */
    public static ApplicationDelegate sharedInstance() {
        return sInstance;
    }

}/** end class. */
