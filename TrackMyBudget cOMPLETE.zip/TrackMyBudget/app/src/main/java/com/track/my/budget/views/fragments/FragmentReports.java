package com.track.my.budget.views.fragments;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.Item;

/**
 * Reports Fragment
 */
public class FragmentReports extends Fragment {

    private TextView tvBudget;
    private TextView tvIncome;
    private TextView tvExpense;
    private TextView tvBalance;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_main_reports, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.tvBudget = view.findViewById(R.id.tvBudget);
        this.tvIncome = view.findViewById(R.id.tvIncome);
        this.tvExpense = view.findViewById(R.id.tvExpense);
        this.tvBalance = view.findViewById(R.id.tvBalance);

        String currency = ApplicationDelegate.sharedInstance().getBudget().getCurrency();

        this.tvBudget.setText("Budget: " + currency + " " + ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount());

        int income = 0;
        int expense = 0;
        int balance = 0;

        for (int i = 1; i < ApplicationDelegate.sharedInstance().getBudget().getItems().size(); i++) {
            Item item = ApplicationDelegate.sharedInstance().getBudget().getItems().get(i);
            if (item.getCategory().getType() == Category.CATEGORY_TYPE_EXPENSE) {
                expense += item.getAmount();
            } else {
                income += item.getAmount();
            }
        }
        balance = income - expense;
        this.tvIncome.setText("Income: " + currency + " " + income);
        this.tvExpense.setText("Expenses: " + currency + " " + expense);
        String balanceStr = "";
        if (balance < 0) {
            tvBalance.setTextColor(Color.RED);
            balanceStr = "Balance " + currency + " " + balance + "\nYour balance is in deficit, please re-think your expenses";
        } else {
            tvBalance.setTextColor(Color.parseColor("#1e90ff"));
            balanceStr = "Balance " + currency + " " + balance + "\nYou are doing good right now!";
        }
        this.tvBalance.setText(balanceStr);
    }

}/** end class. */
