package com.track.my.budget.views;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.track.my.budget.ApplicationDelegate;
import com.track.my.budget.R;
import com.track.my.budget.controller.AlertManager;
import com.track.my.budget.controller.PreferenceController;
import com.track.my.budget.controller.StorageController;
import com.track.my.budget.models.Budget;
import com.track.my.budget.models.Category;
import com.track.my.budget.models.Item;
import com.track.my.budget.models.User;
import com.track.my.budget.util.AlertReceiver;
import com.track.my.budget.views.fragments.FragmentAccounts;
import com.track.my.budget.views.fragments.FragmentCategory;
import com.track.my.budget.views.fragments.FragmentHome;
import com.track.my.budget.views.fragments.FragmentReports;

import java.io.IOException;
import java.util.Calendar;

/**
 * Main Activity class
 */
public class MainActivity extends AppCompatActivity {

    // Toolbar
    private Toolbar toolbar;
    private FloatingActionButton buttAddItem;
    private FloatingActionButton buttAddCategory;

    // Bottom Navigation
    private BottomNavigationView bottomNavigationView;
    private BottomNavigationView.OnNavigationItemSelectedListener onNavigationItemSelectedListener;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set toolbar
        this.setToolbar();

        // Set Bottom Navigation
        this.setBottomNavigation();

        // Set contents
        this.buttAddItem = (FloatingActionButton) findViewById(R.id.buttAddItem);
        this.buttAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewItem();
            }
        });

        this.buttAddCategory = (FloatingActionButton) findViewById(R.id.buttAddCategory);
        this.buttAddCategory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addCategory();
            }
        });

        this.buttAddCategory.hide();
        // Set Main Home View
        this.replaceFragment(new FragmentHome());
    }

    private void setToolbar() {
        this.toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.toolbar.setTitle("Dashboard");
        setSupportActionBar(toolbar);
    }

    private void setToolbarTitle(String title) {
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
        }
    }

    private void setBottomNavigation() {
        this.bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        this.onNavigationItemSelectedListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.navHome:
                        buttAddItem.show();
                        buttAddCategory.hide();
                        setToolbarTitle("Dashboard");
                        replaceFragment(new FragmentHome());
                        return true;
                    case R.id.navCategory:
                        buttAddItem.hide();
                        buttAddCategory.show();
                        setToolbarTitle("Categories");
                        replaceFragment(new FragmentCategory());
                        return true;
                    case R.id.navReports:
                        buttAddItem.hide();
                        buttAddCategory.hide();
                        setToolbarTitle("Reports");
                        replaceFragment(new FragmentReports());
                        return true;
                    case R.id.navAccounts:
                        buttAddItem.hide();
                        buttAddCategory.hide();
                        setToolbarTitle("Account");
                        replaceFragment(new FragmentAccounts());
                        return true;
                }
                return false;
            }
        };

        this.bottomNavigationView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener);
    }

    /**
     *
     * @param inFragment
     */
    private void replaceFragment(Fragment inFragment) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.mainContainer, inFragment);
        ft.commit();
    }

    private void addCategory() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        builder.setTitle("Add Category");
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add_category, null);
        final EditText etName = (EditText) v.findViewById(R.id.etName);
        final Spinner spinCategory = (Spinner) v.findViewById(R.id.spinCategory);
        String[] catTypes = {"Income", "Expense"};
        spinCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, catTypes));
        builder.setView(v);
        builder.setPositiveButton("Apply", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int catType = 0;
                if (spinCategory.getSelectedItem().equals("Expense")) {
                    catType = Category.CATEGORY_TYPE_EXPENSE;
                } else {
                    catType = Category.CATEGORY_TYPE_INCOME;
                }
                Category category = new Category(etName.getText().toString(), catType);
                ApplicationDelegate.sharedInstance().getCategories().add(category);
                try {
                    StorageController.save(MainActivity.this, Category.S_ID, ApplicationDelegate.sharedInstance().getCategories());
                    replaceFragment(new FragmentCategory());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void addNewItem() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this, R.style.AppCompatAlertDialogStyle);
        View v = LayoutInflater.from(this).inflate(R.layout.dialog_add_item, null);
        final EditText etName = (EditText) v.findViewById(R.id.etName);
        final Spinner spinCategory = (Spinner) v.findViewById(R.id.spinCategory);
        TextView tvCurrency = (TextView) v.findViewById(R.id.tvCurrency);
        final EditText etAmount = (EditText) v.findViewById(R.id.etAmount);
        Button buttEndDate = (Button) v.findViewById(R.id.buttEndDate);
        final Button buttAlert = (Button) v.findViewById(R.id.buttAlert);

        String catNames[] = new String[ApplicationDelegate.sharedInstance().getCategories().size()];
        for (int i = 0; i < ApplicationDelegate.sharedInstance().getCategories().size(); i++) {
            catNames[i] = ApplicationDelegate.sharedInstance().getCategories().get(i).getName();
        }
        spinCategory.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, catNames));

        tvCurrency.setText(ApplicationDelegate.sharedInstance().getBudget().getCurrency());

        buttEndDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        buttAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String alertDate = String.format("%d/%d/%d", dayOfMonth, month + 1, year);
                        buttAlert.setText(String.format("%s", alertDate));
                        Intent intent = new Intent(MainActivity.this, AlertReceiver.class);
                        intent.putExtra("title", "Track My Budget");
                        intent.putExtra("name", etName.getText().toString());
                        intent.putExtra("category", spinCategory.getSelectedItem().toString());
                        intent.putExtra("amount", etAmount.getText().toString());
                        new AlertManager(MainActivity.this, intent).setAlertForDate(alertDate);
                        try {
                            StorageController.save(MainActivity.this, Budget.S_ID, ApplicationDelegate.sharedInstance().getBudget());
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        builder.setTitle("Add Item").setPositiveButton("Apply", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Category category = null;
                for (Category c : ApplicationDelegate.sharedInstance().getCategories()) {
                    if (spinCategory.getSelectedItem().equals(c.getName())) {
                        category = c;
                    }
                }
                int amount = Integer.parseInt(etAmount.getText().toString());
                Item item = new Item(etName.getText().toString(), category, amount,
                        null, !buttAlert.getText().toString().isEmpty(), buttAlert.getText().toString(), Item.ITEM_TYPE_ITEM);
                if (category.getType() == Category.CATEGORY_TYPE_EXPENSE) {
                    ApplicationDelegate.sharedInstance().getBudget().setBudgetAmount(ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount() - amount);
                } else {
                    ApplicationDelegate.sharedInstance().getBudget().setBudgetAmount(ApplicationDelegate.sharedInstance().getBudget().getBudgetAmount() + amount);
                }
                ApplicationDelegate.sharedInstance().getBudget().getItems().add(item);
                try {
                    StorageController.save(MainActivity.this, Budget.S_ID, ApplicationDelegate.sharedInstance().getBudget());
                    replaceFragment(new FragmentHome());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                dialog.dismiss();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.setView(v);
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        // Remove this line to disable password requirement on launch time
        PreferenceController.getPreferenceController(this).putBoolean(ApplicationDelegate.KEY_LOGGED_IN, false);

        super.onBackPressed();
    }
}/** end class. */
